const express = require('express');
const controllers = require('../controller/paymentController');

const router = express.Router();

router.get('/payment/:id', controllers.paymentCreate);
router.post('/payment/:id', controllers.paymentCreatePost);
router.get('/paymentInvoice/:id', controllers.paymentInvoice);


module.exports = router;