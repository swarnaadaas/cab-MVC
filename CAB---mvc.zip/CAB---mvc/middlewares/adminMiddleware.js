const admin = require('../model/admin');

module.exports = async (req, res, next) => {
    req.identity = {
        isAuthenticated: false,
        admin: null
    }

    if (req.url == "/adminLogin" || req.url == "/adminRegister") {
        return next();
    }

    let adminId = req.session.adminId;
    if (!adminId || adminId == null) {
        return res.redirect("/adminLogin");
    }

    let adminFromDb = await admin.findByPk(adminId);
    if (adminFromDb == null) {
        return res.redirect("/adminLogin");
    }

    req.identity.isAuthenticated = true;
    req.identity.admin = {
        id: adminFromDb.dataValues.id,
        name: adminFromDb.dataValues.name,
        email: adminFromDb.dataValues.email,
        phone: adminFromDb.dataValues.phone,
        role: 'admin'
    }
    next();
}