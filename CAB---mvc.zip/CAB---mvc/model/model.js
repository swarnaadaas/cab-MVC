const { Sequelize, DataTypes } = require('sequelize');

const db = new Sequelize({
    database: 'cms',
    dialect: 'mysql',
    username: 'root',
    password: 'root'
});

const Admin = db.define('Admin', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    name: {
        type: DataTypes.STRING(50),
        allowNull: false
    },
    email: {
        type: DataTypes.STRING(50),
        allowNull: false,
        unique: true
    },
    password: {
        type: DataTypes.STRING(50),
        allowNull: false
    },
    phone: {
        type: DataTypes.STRING(50),
        allowNull: false
    }
});

const Booking = db.define('Booking', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    pick: {
        type: DataTypes.STRING(50),
        allowNull: false,
    },
    drop: {
        type: DataTypes.STRING(50),
        allowNull: false
    },
    cabType: {
        type: DataTypes.STRING(50),
        allowNull: false
    },
    pickDate: {
        type: DataTypes.DATEONLY,
        allowNull: false,
    },
    pickTime: {
        type: DataTypes.TIME,
        allowNull: false,
    },
    cost: {
        type: DataTypes.INTEGER,
        allowNull: false,
    }
});

const Cab = db.define('Cab', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    cabNo: {
        type: DataTypes.STRING(50),
        allowNull: false,
    },
    cabType: {
        type: DataTypes.STRING(50),
        allowNull: false
    },
    cabCapacity: {
        type: DataTypes.STRING(50),
        allowNull: false,
    }
});

const Driver = db.define('Driver', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    name: {
        type: DataTypes.STRING(50),
        allowNull: false
    },
    email: {
        type: DataTypes.STRING(50),
        allowNull: false,
        unique: true
    },
    license_no: {
        type: DataTypes.STRING(50),
        allowNull: false,
        unique: true
    },
    password: {
        type: DataTypes.STRING(50),
        allowNull: false
    },
    phone: {
        type: DataTypes.STRING(50),
        allowNull: false
    }
});

const Passenger = db.define('Passenger', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    name: {
        type: DataTypes.STRING(50),
        allowNull: false
    },
    email: {
        type: DataTypes.STRING(50),
        allowNull: false,
        unique: true
    },
    password: {
        type: DataTypes.STRING(50),
        allowNull: false
    },
    phone: {
        type: DataTypes.STRING(50),
        allowNull: false
    }
});

const Payment = db.define('Payment', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    pick: {
        type: DataTypes.STRING(50),
        allowNull: false,
    },
    drop: {
        type: DataTypes.STRING(50),
        allowNull: false
    },
    card_no: {
        type: DataTypes.STRING(50),
        allowNull: false
    },
    card_name: {
        type: DataTypes.STRING(50),
        allowNull: false
    },
    card_exp: {
        type: DataTypes.DATEONLY,
        allowNull: false
    },
    pickDate: {
        type: DataTypes.DATEONLY,
        allowNull: false,
    },
    pickTime: {
        type: DataTypes.TIME,
        allowNull: false,
    },
    cost: {
        type: DataTypes.INTEGER,
        allowNull: false,
    }
});

const Place = db.define('Place', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    pick: {
        type: DataTypes.STRING(50),
        allowNull: false,
    },
    drop: {
        type: DataTypes.STRING(50),
        allowNull: false
    },
    cost: {
        type: DataTypes.INTEGER,
        allowNull: false
    }
});

Place.hasMany(Booking, { foreignKey: 'placeId' });
Booking.belongsTo(Place, { foreignKey: 'placeId', onDelete: 'CASCADE', constraints: true })

Passenger.hasMany(Booking, { foreignKey: 'passengerId' });
Booking.belongsTo(Passenger, { foreignKey: 'passengerId', onDelete: 'CASCADE', constraints: true })

Driver.hasMany(Cab, { foreignKey: 'driverId' });
Cab.belongsTo(Driver, { foreignKey: 'driverId', onDelete: 'CASCADE', constraints: true })

Place.hasMany(Payment, { foreignKey: 'placeId' });
Payment.belongsTo(Place, { foreignKey: 'placeId', onDelete: 'CASCADE', constraints: true })

module.exports.Admin = Admin;
module.exports.Booking = Booking;
module.exports.Cab = Cab;
module.exports.Driver = Driver;
module.exports.Passenger = Passenger;
module.exports.Payment = Payment;
module.exports.Place = Place;