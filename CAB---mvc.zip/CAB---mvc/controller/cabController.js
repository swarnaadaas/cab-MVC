const { Sequelize } = require('sequelize');
const trigger = require("../model/model")
const { Cab, Driver } = require('../model/model');

module.exports.index = (req, res, next) => {
    Cab.findAll({
        include: Driver
    }).then(cabs => {
        res.render('cab-index', {
            data: cabs,
            identity: req.identity.admin
        });
    });
}

module.exports.create = (req, res, next) => {
    Driver.findAll().then((driver) => {
        res.render('cab-create', {
            driver_name: driver
        })
    })
};

module.exports.createPost = (req, res, next) => {
    var temp = req.body.driver_name;
    var new_temp = temp.split(':');

    Cab.create({
        cabNo: req.body.cab_no,
        cabType: req.body.cab_type,
        cabCapacity: req.body.cab_capacity,
        driverId: new_temp[1]
    })
        .then(cabFromDb => {
            res.redirect("/index");
        })
}

module.exports.update = async (req, res, next) => {
    Cab.findByPk(req.params.id)
        .then(cabFromDb => {
            res.render('cab-update', {
                data: cabFromDb
            });
        });
}


module.exports.updatePost = async (req, res, next) => {
    await Cab.update(
        {
            cabNo: req.body.cab_no,
            cabType: req.body.cab_type,
            cabCapacity: req.body.cab_capacity,
        },
        {
            where: { id: req.params.id }
        }
    )
    res.redirect('/index');
}

module.exports.delete = async (req, res, next) => {
    let id = req.params.id;
    let cabFromDb = await Cab.findByPk(id);
    if (cabFromDb != null) {
        await Cab.destroy({
            where: {
                id: id
            }
        });
        res.redirect("/index");
    }
}