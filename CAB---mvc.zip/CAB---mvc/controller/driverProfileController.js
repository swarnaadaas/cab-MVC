const { Driver } = require('../model/model');

module.exports.driverProfileIndex = (req, res, next) => {
    Driver.findAll({ where: { id: req.session.driverId } }).then(driverProfiles => {
        res.render('driverProfile-index', {
            data: driverProfiles,
            identity: req.identity.driver
        });
    })
}

module.exports.driverProfileUpdate = async (req, res, next) => {
    Driver.findByPk(req.params.id)
        .then(driverProfileFromDb => {
            res.render('driverProfile-update', {
                data: driverProfileFromDb
            });
        });
}

module.exports.driverProfileUpdatePost = async (req, res, next) => {
    await Driver.update(
        {
            name: req.body.name,
            email: req.body.email,
            license_no: req.body.license_no,
            password: req.body.password,
            phone: req.body.phone,
        },
        {
            where: { id: req.params.id }
        }
    )
    res.redirect('/driverProfileIndex');
}

module.exports.driverProfileDelete = async (req, res, next) => {
    let id = req.params.id;
    let driverProfileFromDb = await Driver.findByPk(id);
    if (driverProfileFromDb != null) {
        await Driver.destroy({
            where: {
                id: id
            }
        });
        res.redirect("/driverLogin");
    }
}
