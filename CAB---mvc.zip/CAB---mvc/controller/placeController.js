const { Place } = require('../model/model');

module.exports.placeIndex = (req, res, next) => {
    Place.findAll().then(places => {
        res.render('place-index', {
            data: places,
            identity: req.identity.admin
        });
    });
}

module.exports.placeCreate = (req, res, next) => {
    res.render('place');
}
module.exports.placeCreatePost = async (req, res, next) => {

    Place.create({
        pick: req.body.pick,
        drop: req.body.drop,
        cost: req.body.cost
    }).then((user) => {
        res.redirect('/placeIndex')
    })
}


module.exports.placeUpdate = async (req, res, next) => {
    Place.findByPk(req.params.id)
        .then(placeFromDb => {
            res.render('place-update', {
                data: placeFromDb
            });
        });
}


module.exports.placeUpdatePost = async (req, res, next) => {
    await Place.update(
        {
            pick: req.body.pick,
            drop: req.body.drop,
            cost: req.body.cost
        },
        {
            where: { id: req.params.id }
        }
    )
    res.redirect('/placeIndex');
}

module.exports.placeDelete = async (req, res, next) => {
    let id = req.params.id;
    let placeFromDb = await Place.findByPk(id);
    if (placeFromDb != null) {
        await Place.destroy({
            where: {
                id: id
            }
        });
        res.redirect("/placeIndex");
    }
}