const { Booking, Cab, Passenger, Place, Driver } = require('../model/model');

module.exports.bookingIndex = (req, res, next) => {
    Booking.findAll({ where: { PassengerId: req.session.passengerId } }).then(bookings => {
        res.render('booking-index', {
            data: bookings,
            identity: req.identity.passenger
        });
    })
}

module.exports.bookingCreate = (req, res, next) => {
    Place.findAll({
        distinct: true
    }

    ).then(placeDetails => {

        res.render('booking-create', { data: placeDetails });
    })

}


module.exports.bookingCreatePost = (req, res, next) => {
    Place.findOne(
        {
            where: {
                pick: req.body.pick,
                drop: req.body.drop
            }
        }
    ).then((placeDetails) => {
        Booking.create({
            pick: req.body.pick,
            drop: req.body.drop,
            cabType: req.body.cab_type,
            pickDate: req.body.pick_date,
            pickTime: req.body.pick_time,
            cost: placeDetails.cost,
            placeId: placeDetails.id,
            passengerId: req.session.passengerId
        }).then(dataFromDB => {
            res.redirect('/payment/' + dataFromDB.id)
        })
    })
}

module.exports.bookingUpdate = async (req, res, next) => {
    Booking.findByPk(req.params.id)
        .then(bookingFromDb => {
            res.render('booking-update', {
                data: bookingFromDb
            });
        });
}


module.exports.bookingUpdatePost = async (req, res, next) => {
    await Booking.update(
        {
            pick: req.body.pick,
            drop: req.body.drop,
            cabType: req.body.cab_type,
            pickDate: req.body.pick_date,
            pickTime: req.body.pick_time
        },
        {
            where: { id: req.params.id }
        }
    )
    res.redirect('/bookingIndex');
}

module.exports.bookingDelete = async (req, res, next) => {
    let id = req.params.id;
    let bookingFromDb = await Booking.findByPk(id);
    if (bookingFromDb != null) {
        await Booking.destroy({
            where: {
                id: id
            }
        });
        res.redirect("/bookingIndex");
    }
}

module.exports.driverCabs = (req, res, next) => {
    Cab.findAll({ where: { driverId: req.session.driverId } }).then(cabs => {
        res.render('driverCab-index', {
            data: cabs,
            identity: req.identity.driver
        });
    })
}
module.exports.driverBookings = (req, res, next) => {
    Booking.findAll({
        include: Passenger
    }).then(bookings => {
        res.render('driverBookings-index', {
            data: bookings,
            identity: req.identity.driver
        });
    })
}
module.exports.adminBookings = (req, res, next) => {
    Booking.findAll({
        include: Passenger
    }).then(bookings => {
        res.render('adminBookings-index', {
            data: bookings,
            identity: req.identity.admin
        });
    })
}


