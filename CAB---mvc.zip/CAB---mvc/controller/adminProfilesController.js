const { Driver, Passenger } = require('../model/model');


module.exports.adminDriverProfileIndex = (req, res, next) => {
    Driver.findAll().then(driverProfiles => {
        res.render('adminDriverProfile-index', {
            data: driverProfiles,
            identity: req.identity.driver
        });
    })
}

module.exports.adminProfileIndex = (req, res, next) => {
    Passenger.findAll().then(Profiles => {
        res.render('adminProfile-index', {
            data: Profiles,
            identity: req.identity.passenger
        });
    })
}
